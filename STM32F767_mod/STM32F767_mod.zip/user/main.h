#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

#include "stm32f7xx_hal.h"
#include "sys.h"
#include "usart.h"

void Error_Handler(void);

#ifdef __cplusplus
}
#endif

#endif





#ifndef __SYS_H
#define __SYS_H

#include "stm32f7xx_hal.h"
#include <stdio.h>
#include <string.h>

extern volatile uint32_t SysTime;

void delay_init(void);
void delay_us(uint32_t us);
void delay_ms(uint32_t ms);


#endif


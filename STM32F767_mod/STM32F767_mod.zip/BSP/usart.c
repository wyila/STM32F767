#include "sys.h"
#include "usart.h"

unsigned char USART2_RX_BUF[USART_BUF_SIZE];
unsigned int USART2_RX_LEN = 0;
unsigned char UART2_TX_STATE = 0;
struct USART_TX_FIFO USART2_TX_FIFO[USART_BUF_SIZE];
struct USART_TX_FIFO *USART2_SEND_PI;
struct USART_TX_FIFO *USART2_INT_PI;

void FIFO_Init(void)
{
    int i;
    for(i = 0; i < USART_BUF_SIZE; i++)
    {
        USART2_TX_FIFO[i].data = 0;
        USART2_TX_FIFO[i].state = 0;
        if(i != (USART_BUF_SIZE - 1))
            USART2_TX_FIFO[i].next = &USART2_TX_FIFO[i + 1];
        else
            USART2_TX_FIFO[i].next = &USART2_TX_FIFO[0];
    }
    USART2_SEND_PI = &USART2_TX_FIFO[0];
    USART2_INT_PI = &USART2_TX_FIFO[0];
}

void USART2_Send(unsigned char *buf, unsigned int len)
{
    uint32_t i;
    
    for(i = 0; i < len; i++)
    {
        USART2_SEND_PI->data = buf[i];
        USART2_SEND_PI->state = 1;
    }
    if(UART2_TX_STATE == 0)
    {
        UART2_TX_STATE = 1;
        USART2->TDR = USART2_INT_PI->data;
        USART2_INT_PI->state = 0;
        USART2_INT_PI = USART2_INT_PI->next;
    }
}











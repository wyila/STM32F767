#include "sys.h"

static unsigned char delay_init_iden = 0;
uint32_t volatile SysTime = 0;

uint32_t fac_ms;
uint32_t fac_us;

int fputc(int ch, FILE *f)
{      
	while((USART2->ISR&0X40)==0);
	USART2->TDR = (uint8_t) ch;      
	return ch;
}

void delay_init(void)
{
    SysTime = 0;
    fac_ms = SysTick->LOAD;
    fac_us = ((fac_ms + 1) / 1000) - 1;
    delay_init_iden = 1;
}

void delay_ms(uint32_t ms)
{
    //记录刚进来的时候定时器的值，实测有1us误差，在这里消除
    unsigned int first_val = SysTick->VAL;
    
    if(delay_init_iden == 0)
    {
        delay_init();
        delay_init_iden = 1;
    }
    if(ms == 0)
        return;
    ms += SysTime;
    
    //不正常情况（SysTime这个变量总有溢出的一天，虽说是小概率。或者说你并没有开启滴答定时器）
    if(ms < SysTime)
        while(ms < SysTime);//等待SysTime归零
    //下面是正常情况
    //等待延时
    while(ms > SysTime);
    //延时差不多达标，但又没完全达标
    //既然程序能走到这里，SysTick->VAL的值一定等于fac_ms，或者稍微比它小一点
    if(first_val < 5)
        first_val = 5;//防止卡bug
    
    while(SysTick->VAL > first_val);    
}

//延时一微秒
void delay_us(uint32_t us)
{
    unsigned int first_val = SysTick->VAL;//记录刚进来的时候定时器的值
    unsigned int ms = SysTime;
    
    if(delay_init_iden == 0)
    {
        delay_init();
        delay_init_iden = 1;
    }
    if(us == 0)
        return;
    
    if(us >= 1000)//超过1ms
    {
        delay_ms(us / 1000);//机智
        ms = SysTime;//更新时间
        us %= 1000;//求余
    }
    
    us *= fac_us;//取滴答定时器延时x us的实际值
    if(us > first_val)
    {
        ms ++;
        while(ms > SysTime);//等待定时器重置
        us -= first_val;
        first_val = fac_ms;//这里fan_ms用SysTick->LOAD更标准
    }
    //到了这里SysTick->Val一定不会比us小
    us = first_val - us;//定时器计数到这，就表示延时完成
    if(us < 5)
        us = 5;//防止卡bug
    //这里us不能等于0，会出事，最好在5以上
    //实测us = 1也不是不行，等待测试结果
    while(SysTick->VAL > us);//等待最后延时
}








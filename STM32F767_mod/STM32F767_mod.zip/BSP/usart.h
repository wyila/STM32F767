#ifndef __USART_H
#define __USART_H

#define USART_BUF_SIZE  200
#define UART_BUF_SIZE   USART_BUF_SIZE

struct USART_TX_FIFO
{
    unsigned char state;
    unsigned char data;
    struct USART_TX_FIFO *next;
};

extern struct USART_TX_FIFO USART2_TX_BUF[USART_BUF_SIZE];
extern unsigned char UART2_TX_STATE;
extern unsigned char USART2_RX_BUF[USART_BUF_SIZE];
extern unsigned int USART2_RX_LEN;
extern struct USART_TX_FIFO USART2_TX_FIFO[USART_BUF_SIZE];
extern struct USART_TX_FIFO *USART2_SEND_PI;
extern struct USART_TX_FIFO *USART2_INT_PI;

void FIFO_Init(void);
void USART2_Send(unsigned char *buf, unsigned int len);

#endif








